﻿namespace Together_Culture
{
    partial class SearchMembersAndVisits
    {
        private System.ComponentModel.IContainer components = null;
        private ComboBox comboBoxMembershipStatus;
        private Button btnSearch;
        private DataGridView dataGridViewResults;
        private Label labelStatus;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.comboBoxMembershipStatus = new ComboBox();
            this.btnSearch = new Button();
            this.dataGridViewResults = new DataGridView();
            this.labelStatus = new Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewResults)).BeginInit();
            this.SuspendLayout();

            // comboBoxMembershipStatus
            this.comboBoxMembershipStatus.FormattingEnabled = true;
            this.comboBoxMembershipStatus.Location = new System.Drawing.Point(20, 20);
            this.comboBoxMembershipStatus.Name = "comboBoxMembershipStatus";
            this.comboBoxMembershipStatus.Size = new System.Drawing.Size(200, 21);
            this.comboBoxMembershipStatus.TabIndex = 0;

            // btnSearch
            this.btnSearch.Location = new System.Drawing.Point(230, 20);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 1;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new EventHandler(this.btnSearch_Click);

            // dataGridViewResults
            this.dataGridViewResults.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewResults.Location = new System.Drawing.Point(20, 60);
            this.dataGridViewResults.Name = "dataGridViewResults";
            this.dataGridViewResults.Size = new System.Drawing.Size(500, 200);
            this.dataGridViewResults.TabIndex = 2;

            // labelStatus
            this.labelStatus.Location = new System.Drawing.Point(20, 280);
            this.labelStatus.Name = "labelStatus";
            this.labelStatus.Size = new System.Drawing.Size(500, 23);
            this.labelStatus.TabIndex = 3;
            this.labelStatus.Text = "Showing 0 results";

            // SearchMembersAndVisits
            this.ClientSize = new System.Drawing.Size(600, 320);
            this.Controls.Add(this.labelStatus);
            this.Controls.Add(this.dataGridViewResults);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.comboBoxMembershipStatus);
            this.Name = "SearchMembersAndVisits";
            this.Text = "Search Members and Visits";
            this.Load += new EventHandler(this.SearchMembersAndVisits_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewResults)).EndInit();
            this.ResumeLayout(false);
        }
    }
}
