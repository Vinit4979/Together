﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace Together_Culture
{
    public partial class EventSearch : Form
    {
        public EventSearch()
        {
            InitializeComponent();
            LoadAllEvents();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string eventName = textBox2.Text.Trim(); // Get event name from TextBox
            DateTime startDate = dateTimePicker1.Value;     // Get start date
            DateTime endDate = dateTimePicker2.Value;         // Get end date

            // Validate date range
            if (startDate > endDate)
            {
                MessageBox.Show("Start date cannot be later than end date.", "Invalid Date Range",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // SQL query to search for events and count total guests
            string query = @"
                SELECT E.Event_Name, E.Event_Date, COUNT(EA.Member_ID) AS TotalGuests
                FROM Events E
                LEFT JOIN EventAttendance EA ON E.Event_ID = EA.Event_ID
                WHERE E.Event_Date BETWEEN @Start_Date AND @End_Date
                AND (@Event_Name IS NULL OR E.Event_Name LIKE '%' + @Event_Name + '%')
                GROUP BY E.Event_Name, E.Event_Date;
            ";
            SqlConnection conn = null;
            try
            {
                conn = ConnectionManager.OpenConnection();

                using (conn)
                {
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@Start_Date", startDate);
                    cmd.Parameters.AddWithValue("@End_Date", endDate);
                    cmd.Parameters.AddWithValue("@Event_Name",
                        string.IsNullOrWhiteSpace(eventName) ? DBNull.Value : eventName);
                    ConnectionManager.OpenConnection();
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    // Bind data to the DataGridView
                    dataGridView1.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionManager.CloseConnection(conn);
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            textBox2.Text = string.Empty;

            // Reset the DateTimePicker controls to today's date
            dateTimePicker1.Value = DateTime.Now.Date;
            dateTimePicker2.Value = DateTime.Now.Date;

            // Clear the DataGridView
            dataGridView1.DataSource = null;

            // Optionally reload all events (unfiltered)
            LoadAllEvents();
        }




        private void LoadAllEvents()
        {
            // Updated query with STRING_AGG to combine attendee names into one cell
            string query = @"
        SELECT 
            E.Event_Name, 
            E.Event_Date, 
            STRING_AGG(M.Member_Name, ', ') AS Attendees
        FROM Events E
        LEFT JOIN EventAttendance EA ON E.Event_ID = EA.Event_ID
        LEFT JOIN Members M ON EA.Member_ID = M.Member_ID
        GROUP BY E.Event_Name, E.Event_Date
        ORDER BY E.Event_Date, E.Event_Name;
    ";

            SqlConnection conn = null;

            try
            {
                conn = ConnectionManager.OpenConnection();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    // Bind the data to the DataGridView
                    dataGridView1.DataSource = dt;

                    // Adjust DataGridView columns
                    dataGridView1.Columns["Event_Name"].HeaderText = "Event Name";
                    dataGridView1.Columns["Event_Date"].HeaderText = "Event Date";
                    dataGridView1.Columns["Attendees"].HeaderText = "Attendees";
                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionManager.CloseConnection(conn);
            }
        }



        // Form Load Event to initialize data
        private void EventSearchForm_Load(object sender, EventArgs e)
        {
            // Optionally load all events when the form loads
            LoadAllEvents();
        }

        private void EventSearch_Load(object sender, EventArgs e)
        {

        }
    }
}
