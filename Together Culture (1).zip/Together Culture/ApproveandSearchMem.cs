﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace Together_Culture
{
    public partial class ApproveandSearchMem : Form
    {
        public ApproveandSearchMem()
        {
            InitializeComponent();
        }

        private void ApproveandSearchMem_Load(object sender, EventArgs e)
        {
            LoadAllMembers();

            SetupDataGridView();
        }

        private void LoadAllMembers()
        {
            string query = @"
        SELECT 
            Member_ID, 
            Member_Name, 
            Member_Email, 
            CASE WHEN IsApproved = 1 THEN 'Approved' ELSE 'Pending' END AS Status
        FROM Members;
    ";

            SqlConnection conn = null;

            try
            {
                conn = ConnectionManager.OpenConnection();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                   
                    dataGridViewMembers.DataSource = dt;

                   
                    if (dataGridViewMembers.Columns["Member_ID"] != null)
                    {
                        dataGridViewMembers.Columns["Member_ID"].Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while fetching members: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionManager.CloseConnection(conn);
            }
        }

        private void SetupDataGridView()
        {
            // Example: Add an "Approve" checkbox column
            if (!dataGridViewMembers.Columns.Contains("Approve"))
            {
                DataGridViewCheckBoxColumn approveColumn = new DataGridViewCheckBoxColumn
                {
                    Name = "Approve",
                    HeaderText = "Approve",
                    Width = 60
                };
                dataGridViewMembers.Columns.Add(approveColumn);
            }

            // Additional formatting, if needed
            dataGridViewMembers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewMembers.AllowUserToAddRows = false; // Prevent adding rows manually
        }
  


        // Search Members Button Click Event
        private void btnSearchMember_Click(object sender, EventArgs e)
        {
            string searchQuery = txtSearchMember.Text.Trim();

            if (string.IsNullOrEmpty(searchQuery))
            {
                MessageBox.Show("Please enter a search term.", "Input Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string query = @"
        SELECT 
            Member_ID, 
            Member_Name, 
            Member_Email, 
            CASE WHEN IsApproved = 1 THEN 'Approved' ELSE 'Pending' END AS Status
        FROM Members
        WHERE 
            Member_Name LIKE '%' + @SearchQuery + '%' 
            OR Member_Email LIKE '%' + @SearchQuery + '%';
    ";

            SqlConnection conn = null;
            try
            {
                conn = ConnectionManager.OpenConnection();
                using (conn)
                {
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@SearchQuery", searchQuery);

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        // Bind data to DataGridView
                        dataGridViewMembers.DataSource = dt;

                        // Optionally hide Member_ID column
                        if (dataGridViewMembers.Columns.Contains("Member_ID"))
                        {
                            dataGridViewMembers.Columns["Member_ID"].Visible = false;
                        }

                        // Add checkbox column for approvals
                        AddApproveColumn();
                    }
                    else
                    {
                        MessageBox.Show("No members found matching the search query.", "No Results",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while searching members: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                // Ensure connection is closed
                ConnectionManager.CloseConnection(conn);
            }
        }


        // Add Checkbox Column for Approving Members
        private void AddApproveColumn()
        {
            // Prevent duplicate checkbox columns
            if (!dataGridViewMembers.Columns.Contains("Approve"))
            {
                DataGridViewCheckBoxColumn approveColumn = new DataGridViewCheckBoxColumn
                {
                    Name = "Approve",
                    HeaderText = "Approve",
                    Width = 50,
                    TrueValue = true,
                    FalseValue = false
                };

                dataGridViewMembers.Columns.Add(approveColumn);
            }
        }

        // Save Changes Button Click Event
        private void btnSaveChanges_Click(object sender, EventArgs e)
        {
            bool updated = false;

            SqlConnection conn = null;
            try
            {
                conn = ConnectionManager.OpenConnection();

                foreach (DataGridViewRow row in dataGridViewMembers.Rows)
                {
                    // Ensure the "Approve" column exists and has a valid value
                    if (row.Cells["Approve"] != null && row.Cells["Approve"].Value != null &&
                        Convert.ToBoolean(row.Cells["Approve"].Value) == true)
                    {
                        int memberId = Convert.ToInt32(row.Cells["Member_ID"].Value);

                        // SQL query to update the IsApproved status
                        string query = "UPDATE Members SET IsApproved = 1 WHERE Member_ID = @Member_ID";

                        try
                        {
                            using (SqlCommand cmd = new SqlCommand(query, conn))
                            {
                                cmd.Parameters.AddWithValue("@Member_ID", memberId);
                                cmd.ExecuteNonQuery(); // Execute the update query
                                updated = true; // Track if any rows were updated
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"An error occurred while approving member ID {memberId}: {ex.Message}",
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }

                // Display a message to indicate the result
                if (updated)
                {
                    MessageBox.Show("Selected members have been approved.", "Success",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Refresh the DataGridView to show updated statuses
                    btnSearchMember.PerformClick();
                }
                else
                {
                    MessageBox.Show("No members were selected for approval.", "Info",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                // Ensure the connection is closed
                ConnectionManager.CloseConnection(conn);
            }
        }

    }
}

