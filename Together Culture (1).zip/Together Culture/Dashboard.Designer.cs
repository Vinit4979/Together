﻿namespace Together_Culture
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            listBox1 = new ListBox();
            SearchMemship = new Button();
            EventButton = new Button();
            listBox2 = new ListBox();
            TagsButton = new Button();
            button4 = new Button();
            button5 = new Button();
            listBox4 = new ListBox();
            Member = new Label();
            label2 = new Label();
            label3 = new Label();
            appseamem = new Label();
            panel1 = new Panel();
            pictureBox5 = new PictureBox();
            panel2 = new Panel();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            button1 = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // listBox1
            // 
            listBox1.Location = new Point(0, 0);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(120, 84);
            listBox1.TabIndex = 18;
            // 
            // SearchMemship
            // 
            SearchMemship.Location = new Point(0, 0);
            SearchMemship.Name = "SearchMemship";
            SearchMemship.Size = new Size(75, 23);
            SearchMemship.TabIndex = 17;
            // 
            // EventButton
            // 
            EventButton.Location = new Point(448, 676);
            EventButton.Margin = new Padding(3, 4, 3, 4);
            EventButton.Name = "EventButton";
            EventButton.Size = new Size(259, 39);
            EventButton.TabIndex = 3;
            EventButton.Text = "Event Search";
            EventButton.UseVisualStyleBackColor = true;
            EventButton.Click += button2_Click;
            // 
            // listBox2
            // 
            listBox2.Location = new Point(0, 0);
            listBox2.Name = "listBox2";
            listBox2.Size = new Size(120, 84);
            listBox2.TabIndex = 21;
            // 
            // TagsButton
            // 
            TagsButton.Location = new Point(0, 0);
            TagsButton.Name = "TagsButton";
            TagsButton.Size = new Size(75, 23);
            TagsButton.TabIndex = 16;
            // 
            // button4
            // 
            button4.Location = new Point(0, 0);
            button4.Name = "button4";
            button4.Size = new Size(75, 23);
            button4.TabIndex = 8;
            // 
            // button5
            // 
            button5.Location = new Point(1034, 464);
            button5.Margin = new Padding(3, 4, 3, 4);
            button5.Name = "button5";
            button5.Size = new Size(259, 39);
            button5.TabIndex = 7;
            button5.Text = "Search Members and Visits";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // listBox4
            // 
            listBox4.FormattingEnabled = true;
            listBox4.Location = new Point(883, 554);
            listBox4.Margin = new Padding(3, 4, 3, 4);
            listBox4.Name = "listBox4";
            listBox4.Size = new Size(581, 184);
            listBox4.TabIndex = 6;
            // 
            // Member
            // 
            Member.Location = new Point(0, 0);
            Member.Name = "Member";
            Member.Size = new Size(100, 23);
            Member.TabIndex = 20;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(296, 530);
            label2.Name = "label2";
            label2.Size = new Size(110, 20);
            label2.TabIndex = 9;
            label2.Text = "Event Overview";
            // 
            // label3
            // 
            label3.Location = new Point(0, 0);
            label3.Name = "label3";
            label3.Size = new Size(100, 23);
            label3.TabIndex = 19;
            // 
            // appseamem
            // 
            appseamem.AutoSize = true;
            appseamem.Location = new Point(883, 530);
            appseamem.Name = "appseamem";
            appseamem.Size = new Size(174, 20);
            appseamem.TabIndex = 11;
            appseamem.Text = "Approve Search Member";
            // 
            // panel1
            // 
            panel1.Controls.Add(pictureBox5);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1802, 125);
            panel1.TabIndex = 13;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(12, 12);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(145, 76);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 18;
            pictureBox5.TabStop = false;
            // 
            // panel2
            // 
            panel2.Controls.Add(button1);
            panel2.Controls.Add(button5);
            panel2.Controls.Add(button4);
            panel2.Controls.Add(pictureBox4);
            panel2.Controls.Add(EventButton);
            panel2.Controls.Add(pictureBox3);
            panel2.Controls.Add(TagsButton);
            panel2.Controls.Add(SearchMemship);
            panel2.Controls.Add(appseamem);
            panel2.Controls.Add(listBox1);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(listBox4);
            panel2.Controls.Add(Member);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(listBox2);
            panel2.Dock = DockStyle.Fill;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(1802, 1055);
            panel2.TabIndex = 14;
            panel2.Paint += panel2_Paint;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(883, 354);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(581, 384);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 15;
            pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.White;
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(296, 354);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(581, 384);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 14;
            pictureBox3.TabStop = false;
            // 
            // button1
            // 
            button1.Location = new Point(1034, 659);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(259, 39);
            button1.TabIndex = 22;
            button1.Text = "Membership Type Management";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Dashboard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoScroll = true;
            BackColor = Color.Red;
            ClientSize = new Size(1802, 1055);
            Controls.Add(panel1);
            Controls.Add(panel2);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(3, 4, 3, 4);
            Name = "Dashboard";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Dashboard";
            WindowState = FormWindowState.Maximized;
            FormClosing += Dashboard_FormClosing;
            Load += Dashboard_Load;
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private ListBox listBox1;
        private Button SearchMemship;
        private Button EventButton;
        private ListBox listBox2;
        private Button TagsButton;
        
        private Button button4;
        private Button button5;
        private ListBox listBox4;
        private Label Member;
        private Label label2;
        private Label label3;
        private Label appseamem;
        private Panel panel1;
       
        private Panel panel2;
   
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private PictureBox pictureBox5;
        private Button button1;
    }
}