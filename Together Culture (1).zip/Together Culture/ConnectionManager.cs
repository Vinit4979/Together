﻿using Microsoft.Data.SqlClient;

public static class ConnectionManager
{
    // Connection string for the database
    private static readonly string connectionString =
        @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\ajayk\OneDrive\Desktop\New folder\TogetherCultureFinal\Together Culture\DataBase.mdf"";Integrated Security=True;Connect Timeout=30";

    // Method to get a new SqlConnection instance
    public static SqlConnection GetConnection()
    {
        return new SqlConnection(connectionString);
    }

    // Method to open a new connection
    public static SqlConnection OpenConnection()
    {
        SqlConnection conn = GetConnection();
        conn.Open();
        return conn;
    }

    // Method to explicitly close a connection
    public static void CloseConnection(SqlConnection conn)
    {
        if (conn != null && conn.State != System.Data.ConnectionState.Closed)
        {
            conn.Close();
            conn.Dispose();
        }
    }

    internal static void CloseConnection(System.Data.SqlClient.SqlConnection conn)
    {
        throw new NotImplementedException();
    }
}
