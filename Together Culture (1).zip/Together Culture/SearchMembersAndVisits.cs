﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;

namespace Together_Culture
{
    public partial class SearchMembersAndVisits : Form
    {
        public SearchMembersAndVisits()
        {
            InitializeComponent();
        }

        private void SearchMembersAndVisits_Load(object sender, EventArgs e)
        {
            comboBoxMembershipStatus.Items.Clear();
            comboBoxMembershipStatus.Items.Add("Member");
            comboBoxMembershipStatus.Items.Add("Non-Member");
            comboBoxMembershipStatus.SelectedIndex = -1;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            SearchMembersAndVisitsData();
        }

        private void SearchMembersAndVisitsData()
        {
            SqlConnection conn = null;
            try
            {
                conn = ConnectionManager.OpenConnection();

                string membershipStatus = comboBoxMembershipStatus.SelectedItem?.ToString();
                if (string.IsNullOrEmpty(membershipStatus))
                {
                    MessageBox.Show("Please select Member or Non-Member", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string sqlQuery = @"
                    SELECT M.Member_Name, E.Event_Name, E.Event_Date 
                    FROM EventAttendance EA
                    LEFT JOIN Members M ON EA.Member_ID = M.Member_ID
                    LEFT JOIN Events E ON EA.Event_ID = E.Event_ID
                    WHERE (@MembershipStatus = 'Member' AND M.MembershipType IS NOT NULL)
                    OR (@MembershipStatus = 'Non-Member' AND M.MembershipType IS NULL)
                    ORDER BY E.Event_Date;
                ";

                SqlCommand cmd = new SqlCommand(sqlQuery, conn);
                cmd.Parameters.AddWithValue("@MembershipStatus", membershipStatus);

                SqlDataAdapter sqldata = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sqldata.Fill(dt);

                dataGridViewResults.DataSource = dt;
                labelStatus.Text = $"Showing {dt.Rows.Count} results for {membershipStatus}s.";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (conn != null && conn.State == System.Data.ConnectionState.Open)
                {
                    ConnectionManager.CloseConnection(conn);
                }
            }
        }
    }
}
