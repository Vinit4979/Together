﻿namespace Together_Culture
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }



        private void Dashboard_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Close the application
            Application.Exit();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            EventSearch eventSearch = new EventSearch();
            eventSearch.Show();

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Dashboard_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            ApproveandSearchMem approveandSearchMem = new ApproveandSearchMem();
            approveandSearchMem.Show();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            SearchMembersAndVisits search_members_and_visits = new SearchMembersAndVisits();
            search_members_and_visits.Show();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Membership_Type_Management membership_type_management = new Membership_Type_Management();
            membership_type_management.Show();
        }
    }
}
